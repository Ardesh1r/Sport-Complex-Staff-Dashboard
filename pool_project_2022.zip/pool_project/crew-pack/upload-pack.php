<?php
require('../db.php');
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $cardnum = $_POST['cardnum'];
    $type = $_POST['type'];
    $expire = $_POST['expire'];

    $query = "INSERT INTO userpackages (name, cardnum, type, expire)
                          VALUES ('$name', '$cardnum', '$type', '$expire')";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if ($result)
        header("Location: index.php");
}
?>
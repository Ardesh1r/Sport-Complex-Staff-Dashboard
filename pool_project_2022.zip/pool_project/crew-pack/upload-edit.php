<?php
require('../db.php');
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $cardnum = $_POST['cardnum'];
    $type = $_POST['type'];
    $expire = $_POST['expire'];
    $ids=$_POST['id'];

    $query="UPDATE userpackages SET name='$name', cardnum='$cardnum', type='$type', expire='$expire' WHERE id='$ids'";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if ($result) header("Location: index.php");
}
?>
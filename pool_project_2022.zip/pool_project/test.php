<?php
$x = 5;
echo $GLOBALS['x'];

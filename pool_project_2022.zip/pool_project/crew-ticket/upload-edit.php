<?php
require('../db.php');
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $price = $_POST['price'];
    $type = $_POST['type'];
    $time = $_POST['time'];

    $query="UPDATE soldtickets SET price='$price', type='$type', time='$time' WHERE id='$id'";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if ($result) header("Location: index.php");
}
?>
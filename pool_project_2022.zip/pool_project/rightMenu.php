<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<div class="sb2-13" dir="rtl">
    <ul class="collapsible" data-collapsible="accordion">
        <li><a href="index.php" class=""><i class="fa fa-bar-chart" aria-hidden="true"></i>
                داشبورد</a>
        </li>
        <li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-user"
                                                                       aria-hidden="true"></i> ویرایش</a>

            <div class="collapsible-body left-sub-menu">
                <ul>
                    <li><a href="listing-all.php"> کارمندان</a></li>
                    <li><a href="listing-packs.php"> پکیج ها</a></li>
                    <li><a href="listing-tickets.php"> بلیت ها</a></li>
                </ul>
            </div>
        </li>
        <li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-user"
                                                                       aria-hidden="true"></i> افزودن</a>

            <div class="collapsible-body left-sub-menu">
                <ul>
                    <li><a href="crew-add.php"> کارمند </a></li>
                    <li><a href="pack-add.php"> پکیج </a></li>
                    <li><a href="ticket-add.php"> بلیت </a></li>
                </ul>
            </div>
        </li>

        <li><a href="logout.php"><i class="fa fa-sign-in" aria-hidden="true"></i> خروج</a>
        </li>
    </ul>
</div>
</div>
</body>
</html>
<?php
require('../db.php');
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $coach = $_POST['coach'];
    $day = $_POST['day'];

    $query = "INSERT INTO class (name, coach, day)
                          VALUES ('$name', '$coach', '$day')";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if ($result)
        header("Location: index.php");
}
?>
<?php
require('../db.php');
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $coach = $_POST['coach'];
    $day = $_POST['day'];
    $ids = $_POST['id'];

    $query="UPDATE class SET name='$name', coach='$coach', day='$day' WHERE id='$ids'";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if ($result) header("Location: index.php");
}
?>
<?php
require('../db.php');
if (isset($_POST['submit'])) {
    $customer = $_POST['customer'];
    $food = $_POST['food'];
    $price = $_POST['price'];
    $numbers = $_POST['numbers'];

    $query = "INSERT INTO `order` (id, customer, food, price, numbers)
            VALUES ('', '$customer', '$food', '$price', '$numbers')";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if ($result) header("Location: index.php");
}
?>
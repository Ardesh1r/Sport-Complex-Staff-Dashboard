<?php
session_start();
unset($_SESSION['personalcode']);
header('Location: ../login-crew.php');
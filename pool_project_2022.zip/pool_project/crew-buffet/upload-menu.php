<?php
require('../db.php');
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $type = $_POST['type'];
    echo $type;
    if ($type == 1)
        $query = "INSERT INTO buffet1 (name, price) VALUES ('$name', '$price')";
    else
        $query = "INSERT INTO buffet2 (name, price) VALUES ('$name', '$price')";

    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if ($result)
        header("Location: index.php");
}
?>
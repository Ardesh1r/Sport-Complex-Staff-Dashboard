<?php session_start();
if (isset($_SESSION['personalcode'])) {
// logged in
?>
<!DOCTYPE html>
<html lang="en">
<?php require("../db.php"); ?>
<head>
    <title>پنل بوفه</title>
    <!--== META TAGS ==-->
    <!--<meta charset="utf-8">-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <!--== FAV ICON ==-->
    <link rel="shortcut icon" href="../images/fav.ico">

    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700" rel="stylesheet">

    <!-- FONT-AWESOME ICON CSS -->
    <link rel="stylesheet" href="../css/font-awesome.min.css">

    <!--== ALL CSS FILES ==-->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/mob.css">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/materialize.css"/>
    <script src="../js/html5shiv.js"></script>
    <script src="../js/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<!--== MAIN CONTRAINER ==-->
<div class="container-fluid sb1">
    <div class="row">
        <!--== LOGO ==-->
        <div class="col-md-2 col-sm-3 col-xs-6 sb1-1">
            <a href="#" class="btn-close-menu"><i class="fa fa-times" aria-hidden="true"></i></a>
            <a href="#" class="atab-menu"><i class="fa fa-bars tab-menu" aria-hidden="true"></i></a>
            <a href="index-2.html" class="logo"><img src="images/logo1.png" alt=""/>
            </a>
        </div>
        <!--== SEARCH ==-->
        <div class="col-md-6 col-sm-6 mob-hide">
        </div>
        <!--== NOTIFICATION ==-->
        <div class="col-md-2 tab-hide">

        </div>
        <!--== MY ACCCOUNT ==-->
        <div class="col-md-2 col-sm-3 col-xs-6">
            <!-- Dropdown Trigger -->
        </div>
    </div>
</div>

<!--== BODY CONTNAINER ==-->
<div class="container-fluid sb2">
    <div class="row">
        <div class="sb2-1">
            <!--== USER INFO ==-->
            <div class="sb2-12">
                <ul>
                    <li></li>
                    <li>
                        <h5><?php echo $_SESSION['personalcode']; ?><span style="color: #eee">کارمند بوفه</span></h5>
                    </li>
                    <li></li>
                </ul>
            </div>
            <!-- RIGHT MENU -->
            <div class="sb2-13" dir="rtl">
                <ul class="collapsible" data-collapsible="accordion">
                    <li><a href="index.php" class=""><i class="fa fa-bar-chart" aria-hidden="true"></i> داشبورد </a>
                    </li>
                    <li><a href="menu-edit.php" class=""><i class="fa fa-user" aria-hidden="true"></i> ثبت منو بوفه</a>
                    </li>
                    <li><a href="order.php" class="menu-active"><i class="fa fa-address-card-o" aria-hidden="true"></i>
                            سفارشات </a></li>
                    <li><a href="logout.php"><i class="fa fa-sign-in" aria-hidden="true"></i> خروج</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- END RIGHT MENU -->
    </div>

    <!--== BODY INNER CONTAINER ==-->

    <form method="post" action="order.php">
        <div class="sb2-2" style="min-height: 800px;">


            <div class="sb2-2-3">
                <div class="row" width="100%>

                    <!--== Country Campaigns ==-->
                    <div class="col-md-6">
                        <div class="box-inn-sp">
                            <div class="inn-title" style="background: #3092c1;">
                                <h4>سفارش مشتری</h4>
                            </div>
                            <div class="tab-inn">
                                <div class="table-responsive table-desi">
                                    <table class="table table-hover" ">
                                        <thead>
                                        <tr>
                                            <th style="text-align: center;">نام مشتری</th>
                                            <th style="text-align: center;">نام غذا</th>
                                            <th style="text-align: center;">تعداد</th>
                                            <th style="text-align: center;">فی</th>
                                            <th style="text-align: center;">قیمت کل</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        $query = "SELECT customer, food, price, numbers FROM `order`";
                                        $result = mysqli_query($conn, $query);
                                        while ($row = mysqli_fetch_array($result)) {
                                            echo "<tr>";
                                            echo "<td>" . $row[0] . "</td>";
                                            echo "<td>" . $row[1] . "</td>";
                                            echo "<td>" . $row[2] . "</td>";
                                            echo "<td>" . $row[3] . "</td>";
                                            echo "<td>" . $row[2] * $row[3] . "</td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
</div>
</div>
</div>

</div>
</div>

<!--== BOTTOM FLOAT ICON ==-->
<section>
    <div class="fixed-action-btn vertical">
        <a class="btn-floating btn-large red pulse">
            <i class="large material-icons">mode_edit</i>
        </a>
        <ul>
            <li><a class="btn-floating red"><i class="material-icons">insert_chart</i></a>
            </li>
            <li><a class="btn-floating yellow darken-1"><i class="material-icons">format_quote</i></a>
            </li>
            <li><a class="btn-floating green"><i class="material-icons">publish</i></a>
            </li>
            <li><a class="btn-floating blue"><i class="material-icons">attach_file</i></a>
            </li>
        </ul>
    </div>
</section>

<!--======== SCRIPT FILES =========-->
<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/materialize.min.js"></script>
<script src="../js/custom.js"></script>
<?php } else header("Location: ../login-crew.php"); ?>
</body>
</html>